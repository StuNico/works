<!DOCTYPE html>
<html>
    <head>
        <title> →Title← </title>
        <link href="style.css" type="text/css" rel="stylesheet">
    </head>
    <body>
    <table>
        <tr>
            <th colspan="2"> Application Management </th>
        </tr>
        <tr>
            <td> Insert Datas into DB </td>
            <td> View Datas from the DB </td>
        </tr>
        <tr>
            <td class="dati1"><input type="button" value="Inserisci dati" onClick="document.location.href='Inserimento.php'"></td>
            <td class="dati2"><input type="button" value="Visualizza dati" onClick="document.location.href='Visualizza.php'"></td>
        </tr>
    </table>
    </body>
</html>